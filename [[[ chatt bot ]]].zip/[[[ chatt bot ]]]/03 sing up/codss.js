﻿


$(document).ready(function()
{
 
 
 $("#up").click(function(e){
        e.preventDefault();

    $.ajax({
            method: "POST" ,
            url: "mosajil.php" , 
            data: { 
comment1 : $(".email").val() ,
comment2 : $(".pasword").val() 
       },
            });
      });


//~~~~~~~~~~~~~~~~~~~~~


 $("#up").click(function(){

    $(".dahr").animate(
    {
        opacity: 1 
    } , 5000 );


      });



 
 
 
 
 
 
 //~~~~~~~~~~~~~~~~~~~~~
} );




















